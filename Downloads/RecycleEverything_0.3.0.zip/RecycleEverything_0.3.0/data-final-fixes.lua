
-- Make recipes
require("prototypes.recipes.burn-recipes")

require("prototypes.recipes.recycle-recipes")

require("prototypes.recipes.shredding")
