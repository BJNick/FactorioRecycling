--data.lua

require("prototypes.categories")
require("prototypes.item-group")

require("prototypes.items")
require("prototypes.stacked-items")
require("prototypes.entities")

require("prototypes.recipes")
require("prototypes.technology")
