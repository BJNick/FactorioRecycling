data:extend(
{
  {
    type = "recipe-category",
    name = "iron-recycling"
  },
  {
    type = "recipe-category",
    name = "copper-recycling"
  },
  {
    type = "recipe-category",
    name = "only-iron-recycling"
  },
  {
    type = "recipe-category",
    name = "only-copper-recycling"
  },
  {
    type = "recipe-category",
    name = "both-recycling"
  }
})
