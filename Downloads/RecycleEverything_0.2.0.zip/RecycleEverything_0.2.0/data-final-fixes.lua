
-- Make recipes
require("prototypes.recycle-recipes")
