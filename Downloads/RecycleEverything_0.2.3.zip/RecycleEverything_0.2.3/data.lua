--data.lua

require("scripts.recipe-functions")

require("prototypes.categories")
require("prototypes.item-group")

require("prototypes.items")
require("prototypes.entities")

require("prototypes.recipes")
require("prototypes.technology")
