
-- Make recipes
require("prototypes.recipes.burn-recipes")

require("prototypes.recipes.recycle-recipes")
