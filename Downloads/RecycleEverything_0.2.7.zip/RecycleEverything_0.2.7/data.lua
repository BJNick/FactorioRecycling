--data.lua

require("prototypes.categories.categories")
require("prototypes.categories.item-group")

require("prototypes.items.items")
require("prototypes.items.stacked-items")

require("prototypes.entities.entities")
require("prototypes.entities.burning-furnace")

require("prototypes.recipes.recipes")
require("prototypes.technologies.technology")
